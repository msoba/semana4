package com.example.miappmaterialdesign;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class perfilMascotas extends Fragment {


    private ArrayList<Mascota> fotos;
    private RecyclerView rvfotomascota;
    public mascota_perfil_adapter adaptador;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_perfil_mascotas, container, false);

        rvfotomascota = (RecyclerView) v.findViewById(R.id.rvfotomascota);

        GridLayoutManager glm = new GridLayoutManager(getActivity(), 3);
        rvfotomascota.setLayoutManager(glm);

        inicializaDatos();
        inicializaAdaptador();

        return v;
    }


    public void inicializaAdaptador(){
        adaptador = new mascota_perfil_adapter(fotos, getActivity());
        rvfotomascota.setAdapter(adaptador);
    }

    public void inicializaDatos() {
        fotos = new ArrayList<Mascota>();
        fotos.add(new Mascota(R.drawable.mascota_correa, "Alegre", 15));
        fotos.add(new Mascota(R.drawable.mascota_correa, "Simpatico", 10));
        fotos.add(new Mascota(R.drawable.mascota_correa, "Bonito", 5));
        fotos.add(new Mascota(R.drawable.mascota_correa, "Doki", 2));
        fotos.add(new Mascota(R.drawable.mascota_correa, "Pulgui", 1));

    }
}