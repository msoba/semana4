package com.example.miappmaterialdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class actionBar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_bar);
    }
}